
//Escribir un algoritmo que dado un n�mero del 1 a 7 escriba el correspondiente 
//nombre del d�a de la semana 

Proceso CON06
	
	Definir Dia Como Entero;
	
	Escribir "Introduzca un n�mero para ver con que d�a corresponde: ";
	Leer Dia;
	// Determinar el nombre del dia de la semana
	Si Dia = 1 Entonces 
		Escribir "Lunes";
	Sino Si Dia = 2 Entonces
			Escribir "Martes";
		Sino Si Dia = 3 Entonces
				Escribir "Mi�rcoles";
			Sino Si Dia = 4 Entonces
					Escribir "Jueves";
				Sino Si Dia = 5 Entonces
						Escribir "Viernes";
					Sino Si Dia = 6 Entonces
							Escribir "Sabado";
						Sino Si Dia = 7 Entonces
								Escribir "Domindo";
							Sino
								Escribir "El n�mero debe estar entre 1 y 7";
							FinSi
						FinSi
					FinSi
				FinSi
			FinSi
		FinSi
	FinSi
FinProceso