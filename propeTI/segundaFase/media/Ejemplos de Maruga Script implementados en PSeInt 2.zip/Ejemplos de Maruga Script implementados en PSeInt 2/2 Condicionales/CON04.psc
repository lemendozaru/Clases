
//Escribir un algoritmo que determine si un n�mero le�do desde 
//el teclado es par o impar

Proceso CON04
	
	Definir Numero Como Entero;
	
	Escribir "Introduzca un n�mero entero: ";
	Leer Numero;
	Si Numero % 2 = 0 entonces 
		Escribir "El n�mero introducido es par";
	Sino
		Escribir "El n�mero introducido es impar";
	FinSi
FinProceso
