// Una empresa ha decidido clasificar a sus empleados en cuatro grupos
// 
// Grupo 1: Solteros con menos de 25 a�os.
// Grupo 2: Solteros con 25 a�os a mas.
// Grupo 3: Casados con menos de 34 a�os.
// Grupo 4: Casados con 34 a�os a mas.
// 
// Escriba un algoritmo que determine el grupo que le corresponde a un empleado.

Proceso CON18
	
	Definir Edad Como Entero; 
	Definir EstadoCivil Como Caracter;
	
	Escribir "Introduzca la edad: ";
	Leer Edad;
	Escribir "Introduzca el estado civil: ";
	Leer EstadoCivil;
	
	Si mayusculas(EstadoCivil) ="S" | Edad < 25 Entonces
		Escribir "Grupo 1";
	Sino
		Si mayusculas(EstadoCivil) = "S" & Edad >= 25 Entonces
			Escribir "Grupo 2";
		Sino
			Si mayusculas(EstadoCivil) = "C" & Edad < 34 Entonces
				Escribir "Grupo 3";
			Sino
				Escribir "Grupo 4";
			FinSi
		FinSi
	FinSi
FinProceso
