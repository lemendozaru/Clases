

// Escriba un algoritmo que lea dos n�meros enteros y determinar cu�l 
// es m�ltiplo de cu�l.


Proceso CON29
	
	Definir N1, N2 Como Enteros; 
	
	Escribir "Introduzca un n�mero entero: ";
	Leer N1;
	Escribir "Introduzca otro n�mero entero: ";
	Leer N2;
	
	// Determinar la multiplicidad de los dos n�meros
	Si N1 % N2 = 0 Entonces
		Escribir "El n�mero ", N1, " es m�ltiplo de ", N2;
	Sino Si N2 % N1 = 0 Entonces
			Escribir "El n�mero ", N2, " es m�ltiplo de ", N1;
		Sino  
			Escribir "Los n�meros no son m�ltiplos";
		FinSi
	FinSi
FinProceso
