//Escriba un algoritmo que lea tres n�meros enteros y determine el menor valor positivo. 
//Si los n�meros positivos son iguales, dar como menor a cualquiera de ellos.

Proceso CON24
	
	Definir A, B, C, Menor Como Enteros; 
	Definir Bandera Como Logico;
	
	Escribir "Introduzca un n�mero: ";
	Leer A;
	Escribir "Introduzca un n�mero: ";
	Leer B;
	Escribir "Introduzca un n�mero: ";
	Leer C;
	
	Menor <- 0;
	
	// Determinaci�n del menor   
	Si A > 0 Entonces
		Menor <- A;
		Si B > 0 & B < Menor Entonces
			Menor <- B;
		FinSi
		Si C > 0 & C < Menor Entonces  
			Menor <- C;
		FinSi
		Bandera <- Verdadero;
	Sino
		Si B > 0 Entonces
			Menor <- B;
			Si A > 0 & A < Menor Entonces
				Menor <- A;
			FinSi
			Si C > 0 & C < Menor Entonces
				Menor <- C;
			FinSi
			Bandera <- Verdadero;
		FinSi
		Si C > 0 Entonces
			Menor <- C;
			Si A > 0 & A < Menor Entonces
				Menor <- A;
			FinSi
			Si B > 0 & B < Menor Entonces
				Menor <- B; 
				Bandera <- Verdadero;
			FinSi
			// No exiten n�meros positivos
			
		Sino 
			Bandera <- Falso;
		FinSi
	FinSi
	// Salida de resultados
	Si Bandera Entonces
		Escribir "El menor valor positivos es: ", Menor;
	Sino
		Escribir "No se ha introducido ning�n n�mero positivo";
	FinSi
FinProceso
