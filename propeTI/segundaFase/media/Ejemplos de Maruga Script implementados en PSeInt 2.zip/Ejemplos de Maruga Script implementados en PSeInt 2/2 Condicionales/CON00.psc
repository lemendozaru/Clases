//Escribir un algoritmo que permita realizar las operaciones de suma, resta, 
//divisi�n o multiplicaci�n, dado dos operando introducidos por el usuario. 
//Deshabilitar Limitar la estructura Seg�n a variables de control num�ricas en las Opciones de lenguaje de PSeInt

Proceso Calculadora
	
	Definir Operando1, Operando2 Como Enteros;
	Definir Operador Como Cadena;
	
	Escribir "Entre el primer operando: ";
	Leer Operando1;
	Escribir "Entre el segundo operando: ";
	Leer Operando2;
	Escribir "Entre el operador: ";
	Leer Operador;
	// Realizar el c�lculo en dependencia del operador
	Segun Operador Hacer
		"+": Escribir Operando1 +  Operando2;
		"-": Escribir Operando1 -  Operando2;
		"*": Escribir Operando1 *  Operando2;
		"/": Escribir Operando1 /  Operando2;
			De Otro Modo
			Escribir "Operador no v�lido";
	FinSegun
FinProceso
