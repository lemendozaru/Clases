//	Escribir un algoritmo que dada una calificaci�n en valor num�rico (1, 2,3,4 � 5)
//	indique su equivalente en valor alfab�tico (A,B,C,D � E)  

Proceso CON09
	
	
	Definir N Como Entero;
	
	Escribir "Introduzca un n�mero (1 a 5): ";
	Leer N;
	// Determinar el equivalente en letra
	Segun N hacer
		1: Escribir "Calificaci�n alfab�tica: A";
		2: Escribir "Calificaci�n alfab�tica: B";
		3: Escribir "Calificaci�n alfab�tica: C";
		4: Escribir "Calificaci�n alfab�tica: D";
		5: Escribir "Calificaci�n alfab�tica: E";
		De Otro Modo:
			Escribir "El n�mero no est� en el rango (1 - 5)";
	FinSegun
FinProceso
