// Para ingresar a un cierto espect�culo se requiere ser var�n mayor de 18 a�os. 
// Escriba un algoritmo que decida si una persona puede o no ingresar al espect�culo.   

Proceso CON15
	
	Definir Edad Como Entero;
	Definir Sexo Como Caracter;;
	
	Escribir "Introduzca la edad: ";
	Leer Edad;
	Escribir "Introduzca el sexo (F o M): ";
	Leer Sexo;
	Si Edad > 18 & Sexo = "m" | Sexo = "M" Entonces
		Escribir "Puede ingresar: ";
	Sino    
		Escribir "No puede ingresar: ";
	FinSi
FinProceso
