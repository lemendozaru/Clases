
// Escriba un algoritmo que lea un n�mero entero de 2 d�gitos y si termina 
// en 1 mostrar su primer d�gito, si termina en 2 mostrar la suma de sus 
// d�gitos y si termina en 3 mostrar el producto de sus dos d�gitos.

Proceso CON30
	
	Definir N Como Entero; 
	Definir Decenas, Unidades Como Enteros;
	
	Escribir "Introduzca un n�mero entero de 2 d�gitos: ";
	Leer N;
	Decenas <- trunc(N / 10);
	Unidades <- N % 10;
	
	// Determinar la salida en dependencia del �ltimo d�gito
	Si Unidades = 1 Entonces
		Escribir "El primer d�gito es: ", Decenas;
	Sino Si Unidades = 2 Entonces
			Escribir "La suma de los d�gitos es: ", Decenas + Unidades;
		Sino Si Unidades = 3 Entonces
				Escribir "El producto de los d�gitos es: ", Decenas * Unidades;
			Sino
				Escribir "El �ltimo d�gito del n�mero no termina en 1, 2 o 3";
			FinSi
		FinSi
	FinSi
FinProceso
