// Para ingresar a un cierto espect�culo se requiere ser var�n mayor de 18 a�os. 
// Escriba un proceso que decida si una persona puede o no ingresar al espect�culo.   

Proceso CON14
	
	Definir Edad Como entero;
	Definir Sexo Como Caracter;
	
	Escribir "Introduzca la edad: ";
	Leer Edad;
	Escribir "Introduzca el sexo (F o M): ";
	Leer Sexo;
	Si Edad > 18 entonces
		Si Sexo = "m" | Sexo = "M" entonces
			Escribir "Puede ingresar: ";
		Sino    
			Escribir "No puede ingresar: ";
		FinSi	
	Sino    
		Escribir "No puede ingresar: ";
	FinSi
FinProceso
