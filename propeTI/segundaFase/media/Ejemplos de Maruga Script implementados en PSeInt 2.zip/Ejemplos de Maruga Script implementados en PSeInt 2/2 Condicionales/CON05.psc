// Escribir un algoritmo que detecte si un n�mero le�do desde el teclado 
// es mayor, menor o igual que 100

Proceso CON05
	
	Definir Numero Como Entero;
	
	Escribir "Introduzca un n�mero entero: ";
	Leer Numero;
	Si Numero < 100 Entonces 
		Escribir "El n�mero es menor que 100";
	Sino Si Numero > 100 Entonces
			Escribir "El n�mero es mayor que 100";
		Sino
			Escribir "El n�mero es igual 100";
		FinSi
	FinSi
FinProceso