

//  Escribir un algorimo que lea un n�mero entero de tres d�gitos y determinar si 
//  al menos dos de sus tres d�gitos son iguales.


Proceso CON27
	
	Definir N, Centenas, Decenas, Unidades, Resto Como Enteros;
	
	escribir "Introduzca un n�mero entero de 3 d�gitos: ";
	leer N;
	Centenas <- trunc(N / 100);
	Resto <- N % 100;
	Decenas <- trunc(Resto / 10);
	Resto <- Resto % 10;
	Unidades <- Resto;
	Si Centenas = Decenas | Centenas = Unidades | Decenas = Unidades Entonces
		Escribir "El n�mero tiene al menos dos d�gitos iguales";
	Sino  
		Escribir "El n�mero no tiene dos d�gitos iguales";
	FinSi    
FinProceso
