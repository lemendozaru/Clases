// Escribir un algoritmo que determine si un n�mero es positivo o negativo.


Proceso CON01
	
	Definir Numero Como Entero;
	
	Escribir "Introduzca un n�mero entero: ";
	Leer Numero;
	Si Numero > 0 Entonces
		Escribir "El n�mero es positivo";
	Sino Si Numero = 0 Entonces
			Escribir "El cero no tiene signo";
		Sino	
			Escribir "El n�mero es negativo";
		FinSi
	FinSi
FinProceso