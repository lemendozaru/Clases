
// Escribir un algoritmo que lea dos n�meros desde el teclado y si el primero 
// es mayor que el segundo intercambie sus valores

Proceso CON08
	
	Definir N1, N2, T Como Enteros;
	
	Escribir "Introduzca el n�mero 1: ";
	Leer N1;
	Escribir "Introduzca el n�mero 2: ";
	Leer N2;
	// Determinar el nombre del dia de la semana
	Si N1 > N2 Entonces
		T <- N1;
		N1 <- N2;
		N2 <- T;
		Escribir "N�meros intercambiados";
		Escribir "N�mero 1 : ", N1;
		Escribir "N�mero 2 : ", N2;
	Sino
		Escribir "N�meros sin intercambiar";
		Escribir "N�mero 1 : ", N1;
		Escribir "N�mero 2 : ", N2;
	FinSi
FinProceso