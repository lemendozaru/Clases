// Escribir un algoritmo que dada una calificaci�n en valor alfab�tico (A,B,C,D � E)  
// indique su equivalente en valor num�rico (1, 2,3,4 � 5)
// Deshabilitar Limitar la estructura Seg�n a variables de control num�ricas en las Opciones de lenguaje de PSeInt

Proceso CON010
	
	Definir L Como Cadena;
	
	Escribir "Introduzca una letra (A a E): ";
	Leer L;
	// Determinar el equivalente en n�mero
	Segun L Hacer  
		"a", "A" :
			Escribir "Calificaci�n num�rica: 1";
		"b", "B" : 
			Escribir "Calificaci�n num�rica: 2";
		"c", "C" : 
			Escribir "Calificaci�n num�rica: 3";
		"d", "D" : 
			Escribir "Calificaci�n num�rica: 4";
		"e", "E" : 
			Escribir "Calificaci�n num�rica: 5";
			De Otro Modo  
			Escribir "La letra no est� en el rango (A - E)";
	FinSegun
FinProceso