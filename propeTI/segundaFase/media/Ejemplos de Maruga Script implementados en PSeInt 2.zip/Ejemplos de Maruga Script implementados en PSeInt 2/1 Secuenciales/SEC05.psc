
// Escribir un algoritmo que calcule el �rea de un rect�ngulo

Proceso SEC05
	
	
	Definir Largo, Ancho Como Reales;
	
	Escribir "Introduzca el largo: ";
	Leer Largo;
	Escribir "Introduzca el ancho: ";
	Leer Ancho;
	// Muestra el resultado en la consola 
	Escribir "El �rea del rect�ngulo es: ", Largo * Ancho;
FinProceso