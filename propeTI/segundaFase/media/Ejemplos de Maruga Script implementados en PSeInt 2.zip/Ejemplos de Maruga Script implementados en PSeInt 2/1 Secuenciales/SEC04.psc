
//	 Escribir un algoritmo que sume, reste, multiplique y divida dos n�meros REALES


Proceso SEC04
	
	Definir A, B Como Reales;
	Definir S, R, D, M Como Reales;
	
	Escribir "Introduzca un n�mero real: ";
	Leer A;
	Escribir "Introduzca otro n�mero real: ";
	Leer B;
	// Realizar las operaciones
	S <- A + B;
	R <- A - B;
	M <- A * B;
	// Divisi�n real
	D <- A / B;
	// Muestra los resultados de las operaciones
	Escribir "La suma es: ", S;
	Escribir "La resta es: ", R;
	Escribir "La multiplicaci�n es : ", M;
	Escribir "La divisi�n es: ", D;
FinProceso
