
// Escribir un algoritmo que eval�e la siguiente expresi�n:
// ((A+5)*3) / (2*B - B)

Proceso SEC11
	
	Definir A, B Como Reales;
	
	Escribir "Introduzca el valor de A: ";
	Leer A;
	Escribir "Introduzca el valor de B: ";
	Leer B;
	// Mostrar el resultado de la evaluaci�n 
	Escribir "((A + 5) * 3) / (2 * B - B) = ", ((A + 5) *3) / (2 * B - B);
FinProceso
