
//  Escribir un algoritmo que sume dos n�meros entrados por el usuario


Proceso SEC02
	
	Definir A, B Como Enteros;
	
	Escribir "Introduzca un n�mero: ";
	Leer A;
	Escribir "Introduzca otro n�mero: ";
	Leer B;
	// Muestra el valor de la suma  en la consola
	Escribir "El resultado es: ", A + B;
finProceso
