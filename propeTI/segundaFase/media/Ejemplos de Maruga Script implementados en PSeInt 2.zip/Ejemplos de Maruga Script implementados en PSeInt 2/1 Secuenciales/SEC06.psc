
// Escribir un algoritmo que calcule el �rea de un tri�ngulo:
// Area del tri�ngulo <- (Base * Altura)/2


Proceso SEC06
	
	Definir Base, Altura, Area Como Reales;
	
	Escribir "Introduzca la base: ";
	Leer Base;
	Escribir "Introduzca la altura: ";
	Leer Altura;
	// Realizar las operaciones
	Area <- (Base * Altura)/2;
	// Muestra  el resultado en la consola
	Escribir "El �rea del tri�ngulo es: ", Area;
FinProceso
