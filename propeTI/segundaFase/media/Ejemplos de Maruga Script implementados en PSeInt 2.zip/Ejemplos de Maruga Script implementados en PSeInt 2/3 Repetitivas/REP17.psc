// Escribir un algoritmo que calcule la depreciaci�n de un objeto seg�n el m�todo 
// de la l�nea recta. Calcular el n�mero de a�os que tarda en hacerse 0. En este 
// m�todo el valor original del objeto se divide por su vida (n�mero de a�os). 
// El cociente resultante ser� la cantidad en la que el objeto se deprecia 
// anualmente. Por ejemplo, si un objeto se deprecia 8000 d�lares en diez a�os, 
// entonces la depreciaci�n anual ser� 8000/10=800 d�lares. Por tanto, el valor 
// del objeto habr� disminuido en 800 d�lares cada a�o. N�tese que la depreciaci�n 
// anual es la misma cada a�o cuando se utiliza este m�todo.

Proceso REP17
	
	Definir Vida, Valor, Depreciacion Como Reales;
	Definir Cantidad Como Entero;
	
	Escribir "Valor original del objeto: ";
	Leer Valor;
	Escribir "Cantidad de a�os: ";
	Leer Vida;
	// Calcular la depreciaci�n
	Depreciacion <- Valor / Vida;
	// Determinar la depreciaci�n por a�os
	Cantidad <- 0;
	Mientras Valor > 0.1 Hacer
		Valor <- Valor - Depreciacion;
		Cantidad <- Cantidad + 1;
		Escribir "A�o: ", Cantidad, "     Valor = ", Valor, " pesos";
	FinMientras
FinProceso