// Escribir un algoritmo que detecte si un n�mero es primo o no. 
// Un n�mero es primo si s�lo es divisible por s� mismo y por la unidad.
//
// Ejemplo:   2,3,5,7,11,17,19 son n�meros primos
//            9 no es n�mero primo, es divisible por 1, 9, 3
// El algoritmo para resolver este problema pasa por dividir sucesivamente el 
// n�mero estudiado por 2,3,4, etc., hasta el propio n�mero.
// Los numeros primos son enteros mayores que 1 sin divisores enteros positivos, 
// exceptuando el 1 y ellos mismos. Todos los primos son impares, excepto el 2.
// Solo es necesario comprobar la divisibilidad por numeros superiores a la raiz 
// cuadrada del numero.

Proceso REP16
	
	Definir N Como Entero;         // Guardamos el valor del numero introducido
	Definir RRaiz Como Entero;     // Guardamos el valor de la raiz del numero
	Definir NoEsPrimo Como Logico; // Variable para decir que un numero no es primo
	Definir EsPar Como Logico;     // Nos sirve para marcar los numeros que son pares
	Definir I Como Entero;         // Variable que usamos dentro del bucle
	NoEsPrimo <- Falso;
	
	// Pedimos un n�mero y no lo aceptamos hasta que sea > 1
	Repetir
		Escribir "Introduzca un n�mero entero mayor que 1: ";
		Leer N;
	Hasta Que N > 1; 
	// EsPar va a ser verdadero cuando el numero sea par
	EsPar <- N % 2 = 0; 
	// 2 es el unico n�mero par que lo es
	Si N = 2 Entonces
		Escribir "El 2 es primo, es el �nico n�mero par que lo es.";
	Sino Si EsPar entonces
			Escribir "Todo n�mero par no es primo, excepto el 2.";
			// Analizar los n�meros impares
		Sino
			// Almacenamos la raiz del n�mero, redondeada
			RRaiz <- redon(rc(N));
			// Comprobamos la divisibilidad de los n�meros superiores a la raiz cuadrada 
			// del n�mero introducido. Si algun n�mero divide al n�mero, NoEsPrimo toma 
			// el valor verdadero
			Para I <- RRaiz Hasta N - 1 Hacer
				Si N % I = 0 Entonces
					NoEsPrimo <- Verdadero;
			    FinSi
			FinPara
			
            // Mostramos en la consola si el n�mero es primo o no
			Si NoEsPrimo Entonces
				Escribir N, " no es un n�mero primo";
			Sino
				Escribir N, " es un n�mero primo";
			FinSi
		FinSi
	FinSi
FinProceso