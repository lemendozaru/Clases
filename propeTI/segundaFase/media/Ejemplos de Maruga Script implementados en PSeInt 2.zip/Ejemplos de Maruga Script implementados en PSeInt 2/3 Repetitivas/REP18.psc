
// Escribir un algoritmo que calcule la depreciaci�n de un objeto seg�n el m�todo 
// del balance doblemente declinante. En este m�todo, el valor del objeto disminuye 
// cada a�o en un porcentaje constante. Por tanto, la verdadera cantidad depreciada, 
// en pesos, variara de un a�o al siguiente. Para obtener el factor de depreciaci�n, 
// dividimos por dos la vida del objeto. Este factor se multiplica por el valor del 
// objeto al comienzo de cada a�o (y no el valor del original del objeto) para obtener 
// la depreciaci�n anual. Supongamos, por ejemplo que deseamos depreciar un objeto 
// de 8000 pesos por diez a�os; el factor de depreciaci�n ser� 2/10=0.2. Por tanto, 
// la depreciaci�n el primer a�o ser� 0,2 X 8000 = 1600 pesos, la depreciaci�n 
// del segundo a�o ser� 0,2 X 6400=1280 pesos; la depreciaci�n del tercer a�o ser� 
// 0,2 X 5120 = 1024 pesos, y as� sucesivamente.


Proceso REP18
	
	Definir Factor, Vida, Valor, Depreciacion Como Reales;
	Definir Cantidad Como Entero;
	
	Escribir "Valor original del objeto: ";
	Leer Valor;
	Escribir "Cantidad de a�os: ";
	Leer Vida;
	// Calcular el factor de depreciaci�n
	Factor <- 2 / Vida;
	// Determinar la depreciaci�n por a�os
	Cantidad <- 1;
	Repetir
		Depreciacion <- Factor * Valor;
		Valor <- Valor - Depreciacion; 
		Escribir "A�o: ", Cantidad, "     Valor = ", Valor, " pesos";
		Cantidad <- Cantidad + 1;
	Hasta Que Cantidad > Vida;   
	Cantidad <- Cantidad - 1;
	Escribir "El valor a los ", Cantidad, " a�os ser� igual a: ", Valor, " pesos";
FinProceso