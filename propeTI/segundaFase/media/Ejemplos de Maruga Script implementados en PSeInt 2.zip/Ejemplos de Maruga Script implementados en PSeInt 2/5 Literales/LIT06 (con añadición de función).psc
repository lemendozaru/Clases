
// Escribir un algoritmo para obtener la primera posici�n en la que comienza la 
// subcadena "fragi" en la literal "supercalifragilisticoexpialidoso". 
// Utilizar la funci�n POSICION(SUBCADENA, CADENA) que devuelve la posici�n de 
// la primera aparici�n de la subcadena en la cadena.
//Arreglos e �ndices de subcadenas en base 0

Proceso LIT06

  Definir L, SL Como Cadenas;
  
  L <- "supercalifragilisticoexpialidoso";        
  SL <- "fragi";
  Escribir "En la frase ", L , ". La palabra " , SL , " ocupa " Sin Bajar; 
  Escribir "la posici�n: ", posicion(SL,L);
FinProceso

SubProceso Retorno <- Posicion(subcad, cad)
	Definir i, Retorno Como Enteros;
	Retorno <- -1;
	i <- 0;
	
	Mientras i <= Longitud(cad) - Longitud(subcad) Hacer
		Si Subcadena(cad, i, i + Longitud(subcad) - 1) = subcad Entonces
			Retorno <- i; // �Encontrado! Almacenar el �ndice basado-0
			i <- Longitud(cad); //Salir del bucle
		Sino
			i <- i + 1;
		FinSi
    FinMientras
FinSubProceso
