	
// Escribir un algoritmo que sume dos Cadenas. Los datos vienen en el cuerpo del 
// ejercicio.

Proceso LIT01

  Definir Titulo1, Titulo2, Titulo3 Como Cadenas;

  Titulo1 <- "Alien"; 
  Titulo2 <- "Blade"; 
  Titulo3 <- "Runner";
  Escribir "T�TULOS DE PEL�CULAS";
  Escribir Titulo1;
  // Concatenar las literales con "+"
  Escribir concatenar(Concatenar(Titulo2," "),Titulo3); //En perfil taller de inform�tica otra forma podr�a ser: Titulo2 + " " + Titulo3;  
FinProceso
