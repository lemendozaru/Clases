//Base de subcadenas 0
Proceso LIT03
	Definir l Como Cadena;
	l <- "Esto es una prueba";
	Escribir "Resultado: ", eliminar(l, posicion("una", l), 4);
FinProceso

// Declaraci�n de funciones
SubProceso Retorno <- Eliminar(Cad, Indice, Cantidad)
	// Funci�n eliminar:
	// Sintaxis (cadena, pos (o �ndice), cantidad)
	
	// El argumento de cadena puede ser cualquier cadena. 
	// El �ndice o posici�n (pos) especifica desde qu� posici�n comenzar� a eliminarse el n�mero de caracteres. (base 0)
	// l es la longitud de la subcadena que se pretende extraer de la cadena original m�s larga
	
    // Ejemplo: La instrucci�n de la sentencia eliminar(cadena, �ndice, cantidad) cuando
	// �ndice <- 13 y cantidad <- 3 y la variable cad cargada con la cadena "Programaci�n 1" se debe escribir la cadena "Programaci�n".
	
	Definir Retorno Como Cadena;
	Definir i Como Entero;
	
	// Validar el �ndice y la cantidad
	Si Indice < 0 | Indice >= Longitud(Cad) | Cantidad <= 0 Entonces
		Retorno <- Literal; // Retorna la cadena original si el �ndice es inv�lido
	FinSi
	
	// Ajustar la cantidad si excede la longitud de la cadena
	Si Indice + Cantidad > Longitud(Cad) Entonces
		Cantidad <- Longitud(Cad) - Indice; 
	FinSi
	
	// Inicializar la cadena de retorno como vac�a
	Retorno <- "";
	
	// Recorrer la cadena y construir la nueva cadena omitiendo los caracteres a eliminar
	Para i <- 0 Hasta Longitud(Cad) - 1 Hacer
		Si i < Indice | i >= Indice + Cantidad Entonces
			Retorno <- Concatenar(Retorno, Subcadena(Cad, i, i));
		FinSi
	FinPara
FinSubProceso

SubProceso Retorno <- Posicion(subcad, cad)
	Definir i, Retorno Como Enteros;
	Retorno <- -1;
	i <- 0;
	
	Mientras i <= Longitud(cad) - Longitud(subcad) Hacer
		Si Subcadena(cad, i, i + Longitud(subcad) - 1) = subcad Entonces
			Retorno <- i; // �Encontrado! Almacenar el �ndice basado-0
			i <- Longitud(cad); //Salir del bucle
		Sino
			i <- i + 1;
		FinSi
    FinMientras
FinSubProceso