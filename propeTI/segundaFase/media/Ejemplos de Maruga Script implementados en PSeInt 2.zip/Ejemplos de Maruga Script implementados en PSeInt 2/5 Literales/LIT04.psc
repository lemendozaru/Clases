
// Escribir un algoritmo que extraiga la literal "MATICA" de la literal "INFORMATICA". 
// Utilizar la funci�n SUBCADENA(L,P,C), que devuelve una subcadena de L, desde la posici�n 6, 
// el primero de los cuales ocupa la posici�n P de L.
//Nota: Usar un perfil que use los arreglos en base 0

Proceso LIT04

  Definir L Como Cadena;
  
  L <- "INFORM�TICA"; 
  Escribir Subcadena(L, 6, Longitud(L));
Finproceso
 